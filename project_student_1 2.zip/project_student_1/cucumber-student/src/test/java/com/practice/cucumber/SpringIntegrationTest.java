package com.practice.cucumber;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class SpringIntegrationTest {
	
	public ResponseEntity<Student[]> getResponse = null;
	public ResponseEntity<Student> postResponse = null;
	public ResponseEntity<Student> updateResponse = null;
	public ResponseEntity<String> deleteResponse = null;
	
	public void executeGet(String url) {
		RestTemplate restTemplate = new RestTemplate();
		getResponse = restTemplate.getForEntity(url, Student[].class);
	}
	
	public void executePOST(String url) {
		RestTemplate restTemplate = new RestTemplate();
		Student std = new Student(22,"new","new","7 A","Jap");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Student> entity = new HttpEntity<>(std, headers);
		
		postResponse = restTemplate.postForEntity(url, entity, Student.class);
	}
	
	public void executePUT(String url) {
		try {
			RestTemplate restTemplate = new RestTemplate();
			Student std = new Student(1201,"new","new","7 A","IND");
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Student> entity = new HttpEntity<>(std, headers);
			
			updateResponse = restTemplate.exchange(url, HttpMethod.PUT,entity, Student.class);
		} catch(Exception e) {
			updateResponse = new ResponseEntity<Student>(new Student(),HttpStatus.NOT_FOUND);
		}
	}
	
	public void executeDELETE(String url) {
		RestTemplate restTemplate = new RestTemplate();
		Student std = new Student(22,"new","new","7 A","IND");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Student> entity = new HttpEntity<>(std, headers);
		
		deleteResponse = restTemplate.exchange(url, HttpMethod.DELETE,entity, String.class);
	}

}
