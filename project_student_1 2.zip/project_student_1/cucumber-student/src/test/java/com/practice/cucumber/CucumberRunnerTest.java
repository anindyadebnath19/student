package com.practice.cucumber;


import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.spring.CucumberContextConfiguration;


@RunWith(Cucumber.class)
@CucumberContextConfiguration
@CucumberOptions(features = "src/main/resources/StudentTest.feature")
public class CucumberRunnerTest {
	
	@Test
	void contextLoads() {
	}
}
