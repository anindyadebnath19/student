package com.practice.cucumber;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StudentCucumberTest extends SpringIntegrationTest {
	
	@When("^the client calls fetchStudents$")
	public void students_GET_call() throws Throwable {
		executeGet("http://localhost:8090/fetchStudents?id=1000");
	}
	
	@Then("^the client receives GET status code (\\d+)$")
	public void students_GET_call_Status(int statusCode) throws Throwable {
		assertEquals(getResponse.getStatusCodeValue(),200);
	}
	
	@When("^the client calls addStudent$")
	public void students_POST_call() throws Throwable {
		executePOST("http://localhost:8090/addStudent");
	}
	
	@Then("^the client receives POST status code (\\d+)$")
	public void students_POST_call_Status(int statusCode) throws Throwable {
		assertEquals(postResponse.getStatusCodeValue(),200);
	}
	
	@When("^the client calls updateStudent$")
	public void students_PUT_call() throws Throwable {
		executePUT("http://localhost:8090/updateStudent");
	}
	
	@Then("^the client receives PUT status code (\\d+)$")
	public void students_PUT_call_Status(int statusCode) throws Throwable {
		assertEquals(updateResponse.getStatusCodeValue(),200);
	}
	
	@When("^the client calls deleteStudent$")
	public void students_DELETE_call() throws Throwable {
		executeDELETE("http://localhost:8090/deleteStudent");
	}
	
	@Then("^the client receives DELETE status code (\\d+)$")
	public void students_DELETE_call_Status(int statusCode) throws Throwable {
		assertEquals(deleteResponse.getStatusCodeValue(),200);
	}

}
