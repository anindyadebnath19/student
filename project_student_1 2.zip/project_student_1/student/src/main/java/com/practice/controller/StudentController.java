package com.practice.controller;

import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.practice.pojo.Student;
import com.practice.service.StudentService;

@RestController
public class StudentController {
	
	@Autowired
	private StudentService studentService;
	
	Logger logger = LoggerFactory.getLogger(StudentController.class);
	
	/**
	 * Fetch Students end point
	 * Students can be fetched by either standard(class) or id, not with both
	 * @param standard
	 * @param id
	 * @return list of Students
	 */
	
	@GetMapping("/fetchStudents")
	private List<Student> getStudentsByClassById(@RequestParam(name="class", required = false) String standard, @RequestParam(name="id", required = false) String id) {
		long reqId = 0;
		try {
			reqId = Long.parseLong(id);
		} catch(Exception e) {
			return Arrays.asList(new Student(0,"","","",""));
		}
		
		if(standard != null && id != null) {
			return Arrays.asList(new Student(0,"","","",""));
		} else if(standard != null) {
			logger.debug("StudentController :: getStudentsByClassById :: class " + standard);
			return studentService.getStudentsByClass(standard);
		} else if(id != null) {
			logger.debug("StudentController :: getStudentsByClassById :: id " + id);
			return studentService.getStudentsById(reqId);
		}
		
		return null;
	}
	
	/**
	 * To add student
	 * @param student
	 * @return the added student
	 */
	@PostMapping("/addStudent")
	private Student addStudent(@RequestBody Student student) {
		logger.debug("StudentController :: addStudent :: Student " + student);
		return studentService.addStudent(student);
	}
	
	/**
	 * To update a exiting student
	 * @param student
	 * @return empty student object if Id not found else updated student
	 */
	@PutMapping("/updateStudent")
	private Student updateStudent(@RequestBody Student student, HttpServletResponse response) {
		logger.debug("StudentController :: updateStudent :: Student " + student);
		return studentService.updateStudent(student,response);
	}
	
	/**
	 * To delete Student
	 * @param student
	 * @return "Success" if deleted else "Failed"
	 */
	@DeleteMapping("/deleteStudent")
	private String deleteStudent(@RequestBody Student student) {
		logger.debug("StudentController :: deleteStudent :: Student " + student);
		return studentService.deleteStudent(student);
	}
}
