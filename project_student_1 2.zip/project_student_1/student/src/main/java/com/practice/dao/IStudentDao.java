package com.practice.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.repository.CrudRepository;

import com.practice.pojo.Student;


@Transactional
public interface IStudentDao extends CrudRepository<Student, Long>{

	/**
	 * To get Students by class/standard
	 * @param standard
	 * @return List of students
	 */
	public List<Student> findByStandard(String standard);
}
