package com.practice.pojo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.sun.istack.NotNull;

@Entity
@Table(name = "students")
public class Student {
	
	@Id
	@SequenceGenerator(name = "idSeqGen", sequenceName = "idSeq", initialValue = 1000, allocationSize = 100)
	@GeneratedValue(generator = "idSeqGen")
	private long id;
	private String firstName;
	private String lastName;
	@JsonProperty("class")
	private String standard;
	private String nationality;
	
	public Student() {
		super();
	}
	public Student(int id, String firstName, String lastName, String standard, String nationality) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.standard = standard;
		this.nationality = nationality;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getStandard() {
		return standard;
	}
	public void setStandard(String standard) {
		this.standard = standard;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", standard=" + standard
				+ ", nationality=" + nationality + "]";
	}

}
