package com.practice.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.practice.dao.IStudentDao;
import com.practice.pojo.Student;


@Component
public class StudentService {
	
	Logger logger = LogManager.getLogger(StudentService.class);
	
	 @Autowired
	 DataSource dataSource;
	 
	 @Autowired
	 IStudentDao studentDao;
	 
	 /**
	  * To get Student by class
	  * @param standard
	  * @return list of students
	  */
	
	public List<Student> getStudentsByClass(String standard) {
		List<Student> students = new ArrayList<>();
		try {
			logger.debug("StudentService :: getStudentsByClass :: class " + standard);
			students = studentDao.findByStandard(standard);
		} catch(Exception e) {
			logger.error("StudentService :: getStudentsByClass :: " + e.getMessage());
		}
		return students;
	}
	
	/**
	  * To get Student by id
	  * @param id
	  * @return student
	  */
	
	public List<Student> getStudentsById(long id) {
		List<Student> students = new ArrayList<>();
		try {
			logger.debug("StudentService :: getStudentsById :: id " + id);
			students = Arrays.asList(studentDao.findById(id).isPresent()? studentDao.findById(id).get() : new Student());
		} catch(Exception e) {
			logger.error("StudentService :: getStudentsById :: " + e.getMessage());
		}
		return students;
	}
	
	/**
	  * To add student
	  * @param student
	  * @return added student
	  */
	public Student addStudent(Student student) {
		Student savedStudent = new Student();
		try {
			logger.debug("StudentService :: addStudent :: student " + student);
			savedStudent = studentDao.save(student);
		} catch(Exception e) {
			logger.error("StudentService :: addStudent :: " + e.getMessage());
		}
		return savedStudent;
	}
	
	/**
	  * To update student
	  * @param student
	  * @return updated student
	  */
	
	public Student updateStudent(Student student, HttpServletResponse response) {
		Student updateStudent = new Student();
		try {
			logger.debug("StudentService :: updateStudent :: student " + student);
			if(studentDao.existsById(student.getId())) {
				updateStudent = studentDao.save(student);
				response.setStatus(HttpServletResponse.SC_OK);
				logger.debug("StudentService :: updateStudent :: complete ");
			} else {
				response.setStatus(HttpServletResponse.SC_NOT_FOUND);
				updateStudent = student;
				logger.debug("StudentService :: updateStudent :: not found");
			}
			
		} catch(Exception e) {
			logger.error("StudentService :: updateStudent :: " + e.getMessage());
		}
		return updateStudent;
	}
	
	/**
	  * To delete student
	  * @param student
	  * @return "Success" if deleted else "Failed"
	  */
	
	public String deleteStudent(Student student) {
		try {
			logger.debug("StudentService :: deleteStudent :: student " + student);
			studentDao.delete(student);
			return "Success";
		} catch (Exception e) {
			logger.error("StudentService :: deleteStudent :: " + e.getMessage());
			return "Failed";
		}
	}

}
