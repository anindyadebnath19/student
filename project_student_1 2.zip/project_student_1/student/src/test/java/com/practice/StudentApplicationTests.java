package com.practice;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.practice.pojo.Student;

@SpringBootTest
@AutoConfigureMockMvc
class StudentApplicationTests {

	@Autowired
	private MockMvc mockMvc;
	
	@Autowired
	DataSource datasource;
	
	@Test
	void contextLoads() {
	}
	
	// Performing integration test between app and database layer
	@Test
	void dataBase() throws SQLException {
		assertNotNull(datasource.getConnection());
	}
	
	// Performing add student test
	@Test
	public void addStudent() throws Exception {
		Student student = new Student(2000,"Test1First","Test1Last","8 A","Ind");
		String requestJson = new ObjectMapper().writeValueAsString(student);
		
		mockMvc.perform(
	            		MockMvcRequestBuilders.post("/addStudent")
	                    				.contentType(MediaType.APPLICATION_JSON)
	                    				.content(requestJson))
	            						.andExpect(status().isOk());

	}
	
	// Performing get student by id test
	@Test
	public void getStudentById() throws Exception {
		
		mockMvc.perform(
	            		MockMvcRequestBuilders.get("/fetchStudents")
	                    				.param("id", "1000"))
										.andDo(print())
	            						.andExpect(status().isOk()
	            		);

	}
	
	// Performing get student by class test
	@Test
	public void getStudentByClass() throws Exception {
		
		mockMvc.perform(
	            		MockMvcRequestBuilders.get("/fetchStudents")
	                    				.param("class", "4 A"))
										.andDo(print())
	            						.andExpect(status().isOk()
	            		);

	}
	
	// Performing update student test
	//To pass the test case make sure you have the request stident is present in database
	@Test
	public void updateStudent() throws Exception {
		Student student = new Student(1201,"Test1FirstChange","Test1Last","8 A","Ind");
		String requestJson = new ObjectMapper().writeValueAsString(student);
		
		mockMvc.perform(
	            		MockMvcRequestBuilders.put("/updateStudent")
	                    				.contentType(MediaType.APPLICATION_JSON)
	                    				.content(requestJson))
	            						.andExpect(status().isOk());

	}
	
	// Performing delete student test
	@Test
	public void deleteStudent() throws Exception {
		Student student = new Student(2000,"","","","");
		String requestJson = new ObjectMapper().writeValueAsString(student);
		
		mockMvc.perform(
	            		MockMvcRequestBuilders.delete("/deleteStudent")
	                    				.contentType(MediaType.APPLICATION_JSON)
	                    				.content(requestJson))
	            						.andExpect(status().isOk());

	}

}
